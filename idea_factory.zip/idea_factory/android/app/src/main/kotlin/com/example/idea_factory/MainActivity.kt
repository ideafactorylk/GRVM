package com.example.idea_factory

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
